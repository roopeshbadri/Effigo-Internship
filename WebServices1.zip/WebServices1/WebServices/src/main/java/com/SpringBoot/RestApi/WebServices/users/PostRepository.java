package com.SpringBoot.RestApi.WebServices.users;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PostRepository extends JpaRepository<Posts,Integer> {
}
