insert into todo (ID, NAME, DESCRIPTION, TARGET_DATE, DONE)
values(10001,'Roopesh', 'Get AWS Certified', CURRENT_DATE(), false);

insert into todo (ID, NAME, DESCRIPTION, TARGET_DATE, DONE)
values(10002,'Roopesh', 'Get Azure Certified', CURRENT_DATE(), false);

insert into todo (ID, NAME, DESCRIPTION, TARGET_DATE, DONE)
values(10003,'Roopesh', 'Get GCP Certified', CURRENT_DATE(), false);

insert into todo (ID, NAME, DESCRIPTION, TARGET_DATE, DONE)
values(10004,'Roopesh', 'Learn DevOps', CURRENT_DATE(), false);