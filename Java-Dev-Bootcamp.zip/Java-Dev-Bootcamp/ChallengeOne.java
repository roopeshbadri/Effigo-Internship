

public class ChallengeOne {
    public static void main(String[] args) {
        System.out.println(" BBB   RRRR");
        System.out.println("B   B  R  R");
        System.out.println("B   B  R  R");
        System.out.println("B B    RR");
        System.out.println("B   B  R R");
        System.out.println("B   B  R   R");
        System.out.println(" BBB   R    R");
    }
}
