public class UpdatingVariables {
    public static void main(String[] args) {
        int passengers=0;
        passengers+=9;
        System.out.println(passengers);
        passengers-=5;
        System.out.println(passengers);
        passengers-=4;
        System.out.println(passengers);
    }
}
