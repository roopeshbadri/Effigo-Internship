package com.SpringGamingApp.HelloWorld;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

record Person(String name, int age, Address address){};
record Address(String firstLine, String city){};
public class HelloWorldConfiguration {
    @Bean
    public String name(){
        return "Roopesh";
    }
    @Bean
    public int age(){
        return 20;
    }
    @Bean
    @Primary
    public Person person1(){
        return new Person("Ravi", 25,address3());

    }
    @Bean
    public Person person2(){
        return new Person(name(),age(),address2());
    }
    @Bean
    public Person person3(String name, int age, Address address3){
        return new Person(name,age,address3);
    }
    @Bean
    @Primary
    public Address address(){
        return new Address("Kundanpally","Secundrabad");
    }
    @Bean
    public Address address2(){
        return new Address("Boduupal", "Hyderabad");
    }
    @Bean
    public Address address3(){
        return new Address("Gachibowli","Bangalore");
    }
}
