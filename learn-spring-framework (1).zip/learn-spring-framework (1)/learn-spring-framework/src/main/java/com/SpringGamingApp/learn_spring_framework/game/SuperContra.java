package com.SpringGamingApp.learn_spring_framework.game;

public class SuperContra implements GamingConsole {
    public void up(){
        System.out.println("Jump Contra");
    }
    public void down(){
        System.out.println("slide");
    }
    public void left(){
        System.out.println("left");
    }
    public void right(){
        System.out.println("right");
    }
}
