package com.SpringGamingApp.learn_spring_framework;

import com.SpringGamingApp.learn_spring_framework.game.GameRunner;
import com.SpringGamingApp.learn_spring_framework.game.Pacman;

public class App01Gaming {
    public static void main(String args[]){
        var game = new Pacman();
        var gameRunner = new GameRunner(game);
        gameRunner.run();
    }
}
