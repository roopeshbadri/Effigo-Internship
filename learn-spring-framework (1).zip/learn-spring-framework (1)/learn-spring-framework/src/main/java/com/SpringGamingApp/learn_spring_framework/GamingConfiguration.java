package com.SpringGamingApp.learn_spring_framework;

import com.SpringGamingApp.learn_spring_framework.game.GameRunner;
import com.SpringGamingApp.learn_spring_framework.game.GamingConsole;
import com.SpringGamingApp.learn_spring_framework.game.Pacman;
import org.springframework.context.annotation.Bean;

public class GamingConfiguration {
    @Bean
    public GamingConsole game(){
        Pacman game = new Pacman();
        return game;
    }
    @Bean
    public GameRunner gameRunner(){
        GameRunner gameRunner=new GameRunner(game());
        return gameRunner;
    }
}
