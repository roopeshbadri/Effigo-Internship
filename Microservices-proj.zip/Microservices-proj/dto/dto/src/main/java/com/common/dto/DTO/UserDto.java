package com.common.dto.DTO;

import lombok.Data;

@Data
public class UserDto {
    private Long id;
    private String name;
    private String email;
}
