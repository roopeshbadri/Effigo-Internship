package com.spring.microservice_L1.Controller;


import com.common.dto.DTO.UserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    private static final String level_2_URL = "http://localhost:8081/users";

    @Autowired
    private RestClient restClient;

    @GetMapping
    public ResponseEntity<List> getUsers(){
        return restClient.get()
                .uri(level_2_URL + "/all")
                .retrieve()
                .toEntity(List.class);
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getUserById(@PathVariable Long id){
        return restClient.get()
                .uri(level_2_URL+id)
                .retrieve()
                .toEntity(String.class);
    }

    @PostMapping
    public ResponseEntity<UserDto> createUser(@RequestBody UserDto userDto) {
        return restClient.post()
                .uri(level_2_URL+"/save")
                .contentType(MediaType.APPLICATION_JSON)
                .body(userDto)
                .retrieve()
                .toEntity(UserDto.class);
    }

}
