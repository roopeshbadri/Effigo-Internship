package com.spring.microservice_L1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceL1Application {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceL1Application.class, args);
	}

}
