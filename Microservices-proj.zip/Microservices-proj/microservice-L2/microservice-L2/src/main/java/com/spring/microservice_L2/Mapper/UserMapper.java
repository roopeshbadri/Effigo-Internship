package com.spring.microservice_L2.Mapper;

import com.common.dto.DTO.UserDto;
import com.spring.microservice_L2.Entity.User;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserMapper {
    UserDto toDto(User user);
    User toEntity(UserDto userDto);
}
