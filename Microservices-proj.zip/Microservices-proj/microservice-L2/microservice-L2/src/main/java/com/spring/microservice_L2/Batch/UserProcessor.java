package com.spring.microservice_L2.Batch;

import com.spring.microservice_L2.Entity.User;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
public class UserProcessor implements ItemProcessor<User, User> {
    @Override
    public User process(User user) throws Exception {
        user.setName(user.getName().toUpperCase()); // Convert name to uppercase as an example
        return user;
    }
}
