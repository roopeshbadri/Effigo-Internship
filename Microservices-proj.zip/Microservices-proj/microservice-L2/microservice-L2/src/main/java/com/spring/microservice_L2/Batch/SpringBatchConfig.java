package com.spring.microservice_L2.Batch;

import com.spring.microservice_L2.Entity.User;
import jakarta.persistence.EntityManagerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.net.DatagramSocket;

@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {

    @Autowired
    private DataSource dataSource;

//    @Value("classpath:org/springframework/batch/core/schema-drop-postgresql.sql")
//    private Resource dropRepositoryTables;
//
//    @Value("classpath:org/springframework/batch/core/schema-postgresql.sql")
//    private Resource dataRepositorySchema;

    @Bean
    public JpaPagingItemReader<User> reader(EntityManagerFactory entityManagerFactory) {
        JpaPagingItemReader<User> reader = new JpaPagingItemReader<>();
        reader.setEntityManagerFactory(entityManagerFactory);
        reader.setQueryString("SELECT * FROM User u ORDER BY u.id ASC"); // JPQL query
        reader.setPageSize(10);
        return reader;
    }

    @Bean
    public ItemWriter<User> writer() {
        return users -> users.forEach(System.out::println);
    }

    @Bean
    public Step userStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("userStep", jobRepository)
                .<User, User>chunk(10, transactionManager)
                .reader(reader(null)) // Inject reader
                .processor(new UserProcessor()) // Process data
                .writer(writer()) // Write to console
                .build();
    }

    @Bean
    public Job userJob(JobRepository jobRepository) {
        return new JobBuilder("userJob", jobRepository)
                .start(userStep(jobRepository, null))
                .build();
    }

}
