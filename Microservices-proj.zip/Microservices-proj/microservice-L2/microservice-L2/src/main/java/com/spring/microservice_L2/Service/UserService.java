package com.spring.microservice_L2.Service;

import com.common.dto.DTO.UserDto;
import com.spring.microservice_L2.Entity.User;
import com.spring.microservice_L2.Mapper.UserMapper;
import com.spring.microservice_L2.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserMapper userMapper;

    public UserDto getUserById(Long id){
        return userRepository.findById(id)
                .map(userMapper::toDto)
                .orElseThrow(() -> new RuntimeException("User not Found..."));
    }

    public List<UserDto> getAllUsers(){
        List<UserDto> users = userRepository.findAll()
                .stream().map(userMapper :: toDto)
                .toList();

        return users;
    }

    public UserDto createUser(UserDto userDto) {
        User user = userMapper.toEntity(userDto);
        User savedUser = userRepository.save(user);
        return userMapper.toDto(savedUser);
    }
}
