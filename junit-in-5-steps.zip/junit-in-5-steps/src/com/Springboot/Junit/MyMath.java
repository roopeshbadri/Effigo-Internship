package com.Springboot.Junit;

public class MyMath {
	public int sum(int[] numbers) {
		int sum=0;
		for(int x:numbers) {
			sum+=x;
		}
		return sum;  
	}

}
