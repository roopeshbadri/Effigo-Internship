package com.Springboot.Junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MyMathTest {
	private MyMath math = new MyMath();
	 @Test
	 public void threeMemberArray() {
					assertEquals(6, math.sum(new int[] {1,2,3}));
		}
	 @Test
		void calculateSum_ZeroLengthArray() {		
			assertEquals(0, math.sum(new int[] {}));
		}
}
	
