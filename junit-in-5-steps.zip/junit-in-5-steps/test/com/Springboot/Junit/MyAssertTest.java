package com.Springboot.Junit;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

class MyAssertTest {
	List<String> todos= Arrays.asList("AWS","DevOps","Azure");
	@Test
	void test() {
		boolean test= todos.contains("AWS");
		//assertEquals(test,true);
		assertTrue(test);
		assertEquals(3,todos.size());
		assertArrayEquals(new int[] {1,2,3},new int[] {1,2,3});
	}

}
