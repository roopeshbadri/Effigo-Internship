package com.employee.employee_service.Constants;


public class AppConstants {

    String SAVED_SUCCESSFULLY = "Saved successfully";

}

