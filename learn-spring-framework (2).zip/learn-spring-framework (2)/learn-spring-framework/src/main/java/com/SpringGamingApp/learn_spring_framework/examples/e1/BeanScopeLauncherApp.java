package com.SpringGamingApp.learn_spring_framework.examples.e1;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.*;
import org.springframework.stereotype.Component;
import java.util.*;
@Component
class Normal{

}
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
class Prototype{

}
@Configuration
@ComponentScan
public class BeanScopeLauncherApp {

    public  static void main(String[] args) {
        var context = new AnnotationConfigApplicationContext(BeanScopeLauncherApp.class);
//      Arrays.stream(context.getBeanDefinitionNames()).forEach(System.out::println);
        System.out.println(context.getBean(Normal.class));
        System.out.println(context.getBean(Normal.class));
        System.out.println(context.getBean(Prototype.class));
        System.out.println(context.getBean(Prototype.class));
        System.out.println(context.getBean(Prototype.class));
    }
}
