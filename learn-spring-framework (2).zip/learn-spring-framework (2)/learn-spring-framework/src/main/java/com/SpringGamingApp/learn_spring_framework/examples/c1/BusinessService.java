package com.SpringGamingApp.learn_spring_framework.examples.c1;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Arrays;


@Service
public class BusinessService{
    private DataService dataService;
    public BusinessService(DataService dataService){
        super();
        this.dataService=dataService;
    }


    public int findMax() {
        return Arrays.stream(dataService.retrieveData()).max().orElse(0);
    }


}
