package com.SpringGamingApp.learn_spring_framework.examples.c1;

import org.springframework.stereotype.Component;

@Component
public interface DataService {
    public int[] retrieveData();
}
