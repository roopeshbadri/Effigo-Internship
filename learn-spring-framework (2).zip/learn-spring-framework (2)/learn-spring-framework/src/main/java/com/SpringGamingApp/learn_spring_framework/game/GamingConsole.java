package com.SpringGamingApp.learn_spring_framework.game;

public interface GamingConsole {
    void up();
    void down();
    void left();
    void right();
}
