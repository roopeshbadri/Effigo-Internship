package com.SpringGamingApp.learn_spring_framework.game;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
@Primary
@Component
public class MarioGame implements GamingConsole {
    public void up(){
        System.out.println("Jump Mario");
    }
    public void down(){
        System.out.println("slide");
    }
    public void left(){
        System.out.println("left");
    }
    public void right(){
        System.out.println("right");
    }
}
