package com.project.Mappers.Controller;

import com.project.Mappers.DTO.PayloadExternalDTO;
import com.project.Mappers.DTO.PayloadInternalDTO;
import com.project.Mappers.Entity.PayloadEntity;
import com.project.Mappers.Service.PayloadService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PayloadController {
    private PayloadService payloadService;
    public PayloadController(PayloadService paymentService) {
        this.payloadService = paymentService;
    }

    // Endpoint to receive an external DTO and convert it to internal DTO
    @PostMapping("/convert")
    public ResponseEntity<PayloadInternalDTO> convertToInternal(@RequestBody PayloadExternalDTO payloadExternalDTO) {
        PayloadInternalDTO paymentInternalDTO = payloadService.convertToInternal(payloadExternalDTO);
        return ResponseEntity.ok(paymentInternalDTO); // Return the internal DTO
    }
    @PostMapping("/save")
    public ResponseEntity<PayloadEntity> savePayload(@RequestBody PayloadInternalDTO payloadInternalDTO) {
        PayloadEntity savedEntity = payloadService.savePayload(payloadInternalDTO);
        return ResponseEntity.ok(savedEntity);
    }
}
