package com.project.Mappers.Service;

import com.project.Mappers.DTO.InvoicesDTO;
import com.project.Mappers.DTO.PayloadExternalDTO;
import com.project.Mappers.DTO.PayloadInternalDTO;
import com.project.Mappers.Entity.InvoicesEntity;
import com.project.Mappers.Entity.PayloadEntity;
import com.project.Mappers.Mappers.PayloadMapper;
import com.project.Mappers.Repository.PayloadEntityRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Service
public class PayloadService {
    private PayloadEntityRepository payloadEntityRepository;
    private PayloadMapper payloadMapper;
    public PayloadService(PayloadMapper payloadMapper, PayloadEntityRepository payloadEntityRepository){
        this.payloadMapper=payloadMapper;
        this.payloadEntityRepository=payloadEntityRepository;
    }
    public PayloadInternalDTO convertToInternal(PayloadExternalDTO paymentExternalDTO) {
        return payloadMapper.toInternal(paymentExternalDTO);
    }
    @Transactional
    public PayloadEntity savePayload(PayloadInternalDTO payloadInternalDTO) {
        PayloadEntity payloadEntity = payloadMapper.toPayloadEntity(payloadInternalDTO);
        for (InvoicesDTO invoiceDTO : payloadInternalDTO.getInvoices()) {
            InvoicesEntity invoiceEntity = payloadMapper.toInvoicesEntity(invoiceDTO);
            invoiceEntity.setPayload(payloadEntity);
            payloadEntity.getInvoices().add(invoiceEntity);
        }
        return payloadEntityRepository.save(payloadEntity);
    }
}
