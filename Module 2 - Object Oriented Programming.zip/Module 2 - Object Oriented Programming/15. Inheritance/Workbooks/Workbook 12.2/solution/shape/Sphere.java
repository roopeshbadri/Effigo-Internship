package shape;

public class Sphere extends Shape {


    public Sphere(double radius) {
        super(radius);
    }


}