package model;

public class CarDealership {

}