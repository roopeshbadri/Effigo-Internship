package com.SpringBoot.Mockito.mockito_demo.list;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class ListTest {
    @Test
    void simpleTest(){
        List listmock  = mock(List.class);
        when(listmock.size()).thenReturn(3);
        assertEquals(3, listmock.size());
    }
    @Test
    void multipleReturns(){
        List listmock  = mock(List.class);
        when(listmock.size()).thenReturn(1).thenReturn(2);
        assertEquals(1, listmock.size());
        assertEquals(2, listmock.size());
        assertEquals(2, listmock.size());
    }
    @Test
    void specificParameters(){
        List listmock  = mock(List.class);
        when(listmock.get(0)).thenReturn("Some String back");
        assertEquals("Some String back", listmock.get(0));
        assertEquals(null, listmock.get(1));
    }
    @Test
    void genericParameters(){
        List listmock  = mock(List.class);
        when(listmock.get(Mockito.anyInt())).thenReturn("SomeOrOtherString");
        assertEquals("SomeOrOtherString", listmock.get(0));
        assertEquals("SomeOrOtherString", listmock.get(1));
    }
}
