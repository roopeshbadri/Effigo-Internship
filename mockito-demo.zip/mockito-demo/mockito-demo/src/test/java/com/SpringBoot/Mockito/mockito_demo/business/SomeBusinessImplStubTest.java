package com.SpringBoot.Mockito.mockito_demo.business;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SomeBusinessImplStubTest {
    @Test
    void test(){
        DataService dataServiceStub=new DataServiceStub1();
        SomeBusinessImpl someBusiness = new SomeBusinessImpl(dataServiceStub);
        int result = someBusiness.findTheGreatestFromAllData();
        assertEquals(20,result);
    }
    @Test
    void test1(){
        DataService dataServiceStub=new DataServiceStub2();
        SomeBusinessImpl someBusiness = new SomeBusinessImpl(dataServiceStub);
        int result = someBusiness.findTheGreatestFromAllData();
        assertEquals(35,result);
    }
}
class DataServiceStub1 implements DataService{
    @Override
    public int[] retrieveAllData(){
        return new int[] {10,15,20};
    }
}
class DataServiceStub2 implements DataService{
    @Override
    public int[] retrieveAllData(){
        return new int[] {35};
    }
}