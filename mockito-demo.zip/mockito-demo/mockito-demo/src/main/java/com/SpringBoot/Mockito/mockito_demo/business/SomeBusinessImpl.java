package com.SpringBoot.Mockito.mockito_demo.business;

public class SomeBusinessImpl {
    private DataService dataService;

    public SomeBusinessImpl(DataService dataService) {
        this.dataService = dataService;
    }

    public int findTheGreatestFromAllData(){
        int[] data= dataService.retrieveAllData();
        int greatestValue=Integer.MIN_VALUE;
        for(int i:data){
            if(i>greatestValue){
                greatestValue=i;
            }
        }
        return greatestValue;
    }
}
interface DataService{
    int[] retrieveAllData();
}
