import { useState } from "react";
import axios from "axios";
import "../css/Form.css"

export default function Form(){
  const [paymentName, setPaymentName] = useState("");
  const [payId, setPayId] = useState("");
  const [payType, setPayType] = useState("");
  const [paymentReceiverName, setPaymentReceiverName] = useState("");
  const [amount, setAmount] = useState("");
  const [companyCode, setCompanyCode] = useState("");
  const [transactionCode, setTransactionCode] = useState("");
  const [plant, setPlant] = useState("");
  const [gst, setGst] = useState("");
  
  const [invoices, setInvoices] = useState([]);
  const [invoiceType, setInvoiceType] = useState("");
  const [invoiceDate, setInvoiceDate] = useState("");
  const [invoiceAmount, setInvoiceAmount] = useState("");

  const addInvoice = () => {
    setInvoices([...invoices, { invoice_type: invoiceType, invoice_date: invoiceDate, invoice_amount: invoiceAmount }]);
    setInvoiceType("");
    setInvoiceDate("");
    setInvoiceAmount("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payloadExternal = {
        paymentName,
        pay_id: payId,
        pay_type: payType,
        invoices,
        paymentReceiverName,
        amount,
        companyCode,
        transactionCode,
        plant,
        gst,
      };

      // Convert external payload to internal DTO
      const convertResponse = await axios.post("http://localhost:8080/convert", payloadExternal);
      const payloadInternal = convertResponse.data;

      // Save the converted payload
      await axios.post("http://localhost:8080/save", payloadInternal);

      alert("Payload saved successfully!");
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to save payload");
    }
  };

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit}>
        <h3>Payment Details</h3>
        <input type="text" placeholder="Payment Name" value={paymentName} onChange={(e) => setPaymentName(e.target.value)} required />
        <input type="text" placeholder="Payment ID" value={payId} onChange={(e) => setPayId(e.target.value)} required />
        <input type="text" placeholder="Payment Type" value={payType} onChange={(e) => setPayType(e.target.value)} required />
        <input type="text" placeholder="Receiver Name" value={paymentReceiverName} onChange={(e) => setPaymentReceiverName(e.target.value)} required />
        <input type="text" placeholder="Amount" value={amount} onChange={(e) => setAmount(e.target.value)} required />
        <input type="text" placeholder="Company Code" value={companyCode} onChange={(e) => setCompanyCode(e.target.value)} required />
        <input type="text" placeholder="Transaction Code" value={transactionCode} onChange={(e) => setTransactionCode(e.target.value)} required />
        <input type="text" placeholder="Plant" value={plant} onChange={(e) => setPlant(e.target.value)} required />
        <input type="text" placeholder="GST" value={gst} onChange={(e) => setGst(e.target.value)} required />
  
        <h3>Invoices</h3>
        <input type="text" placeholder="Invoice Type" value={invoiceType} onChange={(e) => setInvoiceType(e.target.value)} />
        <input type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} />
        <input type="text" placeholder="Invoice Amount" value={invoiceAmount} onChange={(e) => setInvoiceAmount(e.target.value)} />
        <button type="button" onClick={addInvoice}>Add Invoice</button>
  
        <ul>
          {invoices.map((inv, index) => (
            <li key={index}>{inv.invoice_type} - {inv.invoice_date} - {inv.invoice_amount}</li>
          ))}
        </ul>
  
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};


