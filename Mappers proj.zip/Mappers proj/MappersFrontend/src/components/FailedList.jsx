import { useState, useEffect } from "react";
import { Spinner, Table } from "react-bootstrap";
import axios from "axios";
import "../css/FailedList.css";

function FailedList() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchFailedPayloads = async () => {
      try {
        const response = await axios.get("http://localhost:8080/failed");
        setData(response.data);
      } catch (err) {
        setError("Failed to fetch failed payloads.");
      } finally {
        setLoading(false);
      }
    };

    fetchFailedPayloads();
  }, []);

  return (
    <div className="page-container">
  <div className="failed-list-container">
    <h5 style={{ marginTop: "20px" }}>Failed Payloads</h5> {/* Reduce spacing */}
    {loading ? (
      <Spinner animation="border" />
    ) : error ? (
      <p>{error}</p>
    ) : data.length === 0 ? (
      <p>No failed payloads found.</p>
    ) : (
      <Table striped bordered hover className="failed-table">
        <thead>
          <tr>
            <th>Payment Name</th>
            <th>Pay ID</th>
            <th>Receiver Name</th>
            <th>Amount</th>
            <th>Company Code</th>
            <th>Transaction Code</th>
            <th>Plant</th>
            <th>GST</th>
            <th>Pay Type</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => (
            <tr key={index}>
              <td>{item.paymentName}</td>
              <td>{item.payId}</td>
              <td>{item.paymentReceiverName}</td>
              <td>{item.amount}</td>
              <td>{item.companyCode}</td>
              <td>{item.transactionCode}</td>
              <td>{item.plant}</td>
              <td>{item.gst}</td>
              <td>{item.payType}</td>
              <td>{item.status}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    )}
  </div>
</div>
  );
}

export default FailedList;
    