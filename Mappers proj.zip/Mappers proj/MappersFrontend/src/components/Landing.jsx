import React from "react";
import { useNavigate } from "react-router-dom";
import "../css/Landing.css";

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div className="landing-container">
      <nav className="navbar">
        <h2 className="logo">PayView</h2>
      </nav>

      {/* Main Section */}
      <div className="main-content">
        <h1>Welcome to PayView</h1>
        <p>Monitor and manage your payment payloads seamlessly.</p>
        <div className="button-container">
          <button className="btn neon-blue" onClick={() => navigate("/success")}>View Successful Payloads</button>
          <button className="btn neon-red" onClick={() => navigate("/failed")}>View Failed Payloads</button>
          <button className="btn neon-green" onClick={() => navigate("/add")}>Add a Payload</button>
        </div>
      </div>
    </div>
  );
}
