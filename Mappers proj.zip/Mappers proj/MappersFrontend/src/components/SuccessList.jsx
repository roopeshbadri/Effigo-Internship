import { useState, useEffect } from "react";
import { Spinner, Table } from "react-bootstrap";
import axios from "axios";
import "../css/SuccessList.css";

function SuccessList() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSuccessPayloads = async () => {
      try {
        const response = await axios.get("http://localhost:8080/success");
        setData(response.data);
      } catch (err) {
        setError("Failed to fetch successful payloads.");
      } finally {
        setLoading(false);
      }
    };

    fetchSuccessPayloads();
  }, []);

  return (
    <div className="page-container">
    <div className="success-list-container">
      <h5>Successful Payloads</h5>
      {loading ? (
        <Spinner animation="border" />
      ) : error ? (
        <p>{error}</p>
      ) : data.length === 0 ? (
        <p>No successful payloads found.</p>
      ) : (
        <Table striped bordered hover className="success-table">
          <thead>
            <tr>
              <th>Payment Name</th>
              <th>Pay ID</th>
              <th>Receiver Name</th>
              <th>Amount</th>
              <th>Company Code</th>
              <th>Transaction Code</th>
              <th>Plant</th>
              <th>GST</th>
              <th>Pay Type</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, index) => (
              <tr key={index}>
                <td>{item.paymentName}</td>
                <td>{item.payId}</td>
                <td>{item.paymentReceiverName}</td>
                <td>{item.amount}</td>
                <td>{item.companyCode}</td>
                <td>{item.transactionCode}</td>
                <td>{item.plant}</td>
                <td>{item.gst}</td>
                <td>{item.payType}</td>
                <td>{item.status}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </div>
    </div>
  );
}

export default SuccessList;
