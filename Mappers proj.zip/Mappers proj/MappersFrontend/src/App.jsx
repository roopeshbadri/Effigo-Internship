import React from "react";
import { BrowserRouter as Router, Routes, Route} from "react-router-dom";
import Form from "./components/Form";
import SuccessList from "./components/SuccessList";
import FailedList from "./components/FailedList";
import Landing from "./components/Landing";
const App = () => {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<Landing/>}></Route>
          <Route path="/add" element={<Form/>}></Route>
          <Route path="/success" element={<SuccessList/>}></Route>
          <Route path="/failed" element={<FailedList/>}></Route>
        </Routes>
      </Router>
    </>
  );
};

export default App;
