package com.project.Mappers.Controller;

import com.project.Mappers.DTO.PayloadExternalDTO;
import com.project.Mappers.DTO.PayloadInternalDTO;
import com.project.Mappers.Entity.FailedEntity;
import com.project.Mappers.Entity.PayloadEntity;
import com.project.Mappers.Service.PayloadService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "http://localhost:5173")
@RestController
public class PayloadController {
    private PayloadService payloadService;
    public PayloadController(PayloadService paymentService) {
        this.payloadService = paymentService;
    }


    @PostMapping("/convert")
    public ResponseEntity<PayloadInternalDTO> convertToInternal(@RequestBody PayloadExternalDTO payloadExternalDTO) {
        PayloadInternalDTO paymentInternalDTO = payloadService.convertToInternal(payloadExternalDTO);
        return ResponseEntity.ok(paymentInternalDTO);
    }
    @PostMapping("/save")
    public ResponseEntity<String> savePayload(@RequestBody PayloadInternalDTO payloadInternalDTO) {
        payloadService.savePayload(payloadInternalDTO);
        return ResponseEntity.ok("saved payload");
    }
    @GetMapping("/success")
    public ResponseEntity<List<PayloadEntity>> getSuccessfulPayloads() {
        List<PayloadEntity> payloads = payloadService.getSuccessfulPayloads();
        return payloads.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(payloads);
    }
    @GetMapping("/failed")
    public ResponseEntity<List<FailedEntity>> getFailedPayloads() {
        List<FailedEntity> fails = payloadService.getFailedPayloads();
        return fails.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(fails);
    }
}

