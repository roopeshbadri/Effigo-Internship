package com.project.Mappers.Entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FailedEntity {
    @Id
    @GeneratedValue
    private Long id;
    private String payType;
    private String paymentName;
    private String payId;
    private String paymentReceiverName;
    private String amount;
    private String companyCode;
    private String transactionCode;
    private String plant;
    private Integer gst;
    @OneToMany(mappedBy = "failedPayload", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<InvoicesEntity> invoices;
    private String failureReason;
    private String status;
}

