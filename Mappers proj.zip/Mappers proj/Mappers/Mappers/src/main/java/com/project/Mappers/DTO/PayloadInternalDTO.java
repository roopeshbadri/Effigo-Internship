package com.project.Mappers.DTO;

import com.project.Mappers.Enums.PayType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PayloadInternalDTO {
    private PaymentHeadersDTO paymentHeaders;
    private List<InvoicesDTO> invoices;
    private PaymentReqDetailsDTO paymentReqDetails;
    private String status;
    private PayType payType;
}


