package com.project.Mappers.Service;

import com.project.Mappers.DTO.InvoicesDTO;
import com.project.Mappers.Enums.PayType;
import com.project.Mappers.DTO.PayloadExternalDTO;
import com.project.Mappers.DTO.PayloadInternalDTO;

import com.project.Mappers.Entity.FailedEntity;
import com.project.Mappers.Entity.InvoicesEntity;
import com.project.Mappers.Entity.PayloadEntity;
import com.project.Mappers.Mappers.PayloadMapper;
import com.project.Mappers.Repository.FailedEntityRepository;
import com.project.Mappers.Repository.PayloadEntityRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class PayloadService {
    private PayloadEntityRepository payloadEntityRepository;
    private PayloadMapper payloadMapper;
    private FailedEntityRepository failedEntityRepository;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public PayloadService(PayloadMapper payloadMapper, PayloadEntityRepository payloadEntityRepository,
                          FailedEntityRepository failedEntityRepository){
        this.payloadMapper=payloadMapper;
        this.payloadEntityRepository=payloadEntityRepository;
        this.failedEntityRepository=failedEntityRepository;
    }
    public PayloadInternalDTO convertToInternal(PayloadExternalDTO paymentExternalDTO) {
        return payloadMapper.toInternal(paymentExternalDTO);
    }

    public void savePayload(PayloadInternalDTO payloadInternalDTO) {
        try {
            validatePayload(payloadInternalDTO);
            PayloadEntity payloadEntity = payloadMapper.toPayloadEntity(payloadInternalDTO);

            if (payloadEntity.getInvoices() == null) {
                payloadEntity.setInvoices(new ArrayList<>());
            }

            for (InvoicesDTO invoiceDTO : payloadInternalDTO.getInvoices()) {
                InvoicesEntity invoiceEntity = payloadMapper.toInvoicesEntity(invoiceDTO);
                invoiceEntity.setPayload(payloadEntity);
                payloadEntity.getInvoices().add(invoiceEntity);
            }

             payloadEntityRepository.save(payloadEntity);
        }
        catch (IllegalArgumentException e) {
            FailedEntity failedEntity = payloadMapper.toFailedEntity(payloadInternalDTO);
            failedEntity.setFailureReason(e.getMessage());
            failedEntityRepository.save(failedEntity);
        }
    }
    public List<PayloadEntity> getSuccessfulPayloads(){
        return payloadEntityRepository.findAll();
    }
    public List<FailedEntity> getFailedPayloads(){
        return failedEntityRepository.findAll();
    }
    private void validatePayload(PayloadInternalDTO payload){
        StringBuilder errorMessages = new StringBuilder();
        if (isNullOrEmpty(payload.getPaymentHeaders().getPaymentName()) ||
                isNullOrEmpty(payload.getPaymentReqDetails().getCompanyCode()) ||
                isNullOrEmpty(payload.getPaymentReqDetails().getPlant())) {
            errorMessages.append("Name, Company Code, and Plant cannot be null or empty. ");
        }

        for(InvoicesDTO invoice : payload.getInvoices()){
            if(isNullOrEmpty((invoice.getInvoice_date()))){
                errorMessages.append("Invoice date cannot be null or empty for invoice type: \" + invoice.getInvoice_type() + \". \"");
            }
            else if (!isValidDateFormat(invoice.getInvoice_date())) {
                errorMessages.append("Invoice date must be in format DD-MM-YYYY for invoice type: " + invoice.getInvoice_type() + ". ");
            }
            else{
                try{
                    LocalDate parsedInvoiceDate = LocalDate.parse(invoice.getInvoice_date(), DATE_FORMATTER);
                    if (parsedInvoiceDate.isBefore((LocalDate.now()))){
                        errorMessages.append("Invoice date cannot be in the past for invoice type: " + invoice.getInvoice_type() + ". ");
                    }
                }catch (Exception e){
                    errorMessages.append("Invalid invoice date format for invoice type: " + invoice.getInvoice_type() + ". ");
                }
            }
        }
        if(payload.getStatus() == null || payload.getStatus().isEmpty()){
            payload.setStatus("1");
        }
        else if ( isInteger(payload.getStatus())){
            payload.setStatus("9");
        }
        else{
            payload.setStatus("7");
        }

        if(payload.getPaymentReqDetails().getAmount() == null){
            payload.setStatus("9");
        }
        if (payload.getPayType() == null || !isOfEnumType(payload.getPaymentHeaders().getPay_type())) {
            errorMessages.append("Invalid payType value. ");
        }
        if(payload.getPaymentReqDetails().getAmount()!=null && ((Integer.parseInt(payload.getPaymentReqDetails().getAmount())<10000))
               && "BANK_CHEQUE".equalsIgnoreCase(payload.getPaymentHeaders().getPay_type()) ){
                errorMessages.append("If amount is less than 10,000, payType cannot be BANK_CHEQUE. ");
        }
        if(!errorMessages.isEmpty()){
            throw new IllegalArgumentException((errorMessages.toString()));
        }
    }
    private boolean isValidPayType(PayType payType) {
        return payType != null;
    }
    private boolean isNullOrEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    private boolean isInteger(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    private boolean isValidDateFormat(String date) {
        try {
            LocalDate.parse(date, DATE_FORMATTER);
            return true;
        } catch (DateTimeParseException e) {

            return false;
        }
    }

    private boolean isOfEnumType(String value) {
        boolean val = Arrays.stream(PayType.values())
                .anyMatch(e -> e.name().equalsIgnoreCase(value));
        return val;
    }

}
