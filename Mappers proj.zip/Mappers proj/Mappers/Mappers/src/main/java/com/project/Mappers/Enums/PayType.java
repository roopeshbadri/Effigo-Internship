package com.project.Mappers.Enums;

public enum PayType {
    CASH,
    CREDIT_CARD,
    DEBIT_CARD,
    BANK_TRANSFER,
    BANK_CHEQUE,
    ONLINE
}
